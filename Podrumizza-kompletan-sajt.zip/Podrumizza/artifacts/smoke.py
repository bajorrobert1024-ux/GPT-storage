#!/usr/bin/env python3
"""Functional checks for the local Podrumizza visual concept; no external messages."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent
BASE = 'http://127.0.0.1:8081/'
checks, errors, failed, bad, methods = [], [], [], [], []
completed = False

def ok(name, detail):
    checks.append({'name': name, 'status': 'passed', 'detail': detail})
    print('PASS:', name, flush=True)

def observe(page):
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('requestfailed', lambda request: failed.append({'url': request.url, 'failure': request.failure}))
    page.on('response', lambda response: bad.append({'url': response.url, 'status': response.status}) if response.status >= 400 else None)
    page.on('request', lambda request: methods.append(request.method))

def no_cart(page):
    expect(page.locator('.selection-button,.selection-count,.selection-modal,.selection-list,.item-add,[data-action="selection"],[data-action="add"],.cart,.cart-drawer')).to_have_count(0)

def booking_tab(page, link):
    with page.expect_popup() as popup_info:
        link.click()
    popup = popup_info.value
    observe(popup)
    popup.wait_for_load_state('networkidle')
    assert popup.url == BASE + 'rezervacija.html', popup.url
    no_cart(popup)
    popup.close()

try:
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
        ctx = browser.new_context(viewport={'width':1440,'height':1000}, accept_downloads=True)
        page = ctx.new_page()
        observe(page)
        names = ['index','jelovnik','karta-pica','digitalni-meni','pizza','rostilj','salate','deserti','o-nama','galerija','kontakt','rezervacija']
        def load(name):
            response = page.goto(BASE + name + '.html', wait_until='networkidle')
            assert response.status == 200, (name,response.status)
            expect(page.locator('h1')).to_have_count(1)
            expect(page.locator('[data-site-header] .site-header')).to_have_count(1)
            expect(page.locator('[data-site-footer] footer')).to_have_count(1)
            expect(page.locator('.wordmark').first).to_have_attribute('href','index.html')
            assert page.locator('[data-site-header] [aria-current]').count() > 0, name
            no_cart(page)
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), f'Overflow1440:{name}'
        def shot(target, filename, full=True):
            target.locator('img').evaluate_all('(imgs)=>imgs.forEach(img=>img.loading="eager")')
            target.wait_for_function('Array.from(document.images).every(img=>img.complete && img.naturalWidth>0)')
            target.evaluate('document.activeElement?.blur(); window.scrollTo({top:0,behavior:"instant"})')
            target.screenshot(path=str(ROOT / filename), full_page=full, style='.skip-link{visibility:hidden!important}')
        from urllib.parse import urljoin, urlparse, unquote
        local_targets = set()
        for name in names:
            load(name)
            assert page.locator('a[target="_blank"]').evaluate_all('(as)=>as.every(a=>a.rel.includes("noopener")&&a.rel.includes("noreferrer"))'), name
            hrefs=page.locator('a[href]').evaluate_all('(as)=>as.map(a=>a.getAttribute("href"))')
            for href in hrefs:
                url=urljoin(page.url,href)
                parsed=urlparse(url)
                if url.startswith(BASE):
                    path=parsed.path
                    if path.endswith('.html'):
                        local_targets.add(path)
                        response=ctx.request.get(url.split('#')[0])
                        assert response.status==200, (name,href,response.status)
                    if parsed.fragment and path==urlparse(page.url).path:
                        assert page.locator('[id]').evaluate_all('(els)=>els.map(e=>e.id)').count(unquote(parsed.fragment))==1,(name,href)
        assert len(local_targets)>=11
        ok('page_crawl_and_shared_navigation','All12 real HTML pages load with one heading/shared header/footer, valid local page links and anchors, protected external tabs, and no cart.')

        load('index')
        destinations=set(page.locator('main a[href]').evaluate_all('(as)=>as.map(a=>a.getAttribute("href")).filter(h=>h.endsWith(".html"))'))
        assert len(destinations)>=6 and 'digitalni-meni.html' in destinations and 'karta-pica.html' in destinations,destinations
        expect(page.locator('[data-destination]')).to_have_count(6)
        shot(page,'desktop.png'); shot(page,'desktop-viewport.png',False)
        booking_tab(page,page.locator('.header-cta'))
        page.locator('[data-destination][href="jelovnik.html"]').click()
        expect(page.locator('#catalog')).to_have_attribute('data-scope','food')
        page.locator('.wordmark').first.click()
        assert page.url==BASE+'index.html'
        page.locator('[data-destination][href="karta-pica.html"]').click()
        expect(page.locator('#catalog')).to_have_attribute('data-scope','drinks')
        ok('home_destinations_and_booking','Home links to at least6 actual destination pages including digital menu/drinks; food/drinks navigation and real booking popup work.')

        food_ids=set()
        drink_ids=set()
        for name,scope,total,screenshot in [('jelovnik','food',23,'food-menu.png'),('karta-pica','drinks',6,'drinks.png')]:
            load(name)
            expect(page.locator('#catalog')).to_have_attribute('data-scope',scope)
            expect(page.locator('#catalog')).to_have_attribute('data-total',str(total))
            expect(page.locator('.menu-item')).to_have_count(min(6,total))
            if page.locator('[data-action="more"]').count():page.locator('[data-action="more"]').click()
            expect(page.locator('.menu-item')).to_have_count(total)
            ids=set(page.locator('.menu-item').evaluate_all('(els)=>els.map(e=>e.dataset.product)'))
            cats=set(page.locator('.menu-item').evaluate_all('(els)=>els.map(e=>e.dataset.category)'))
            if scope=='food':
                assert 'pica' not in cats
                food_ids=ids
                page.locator('#catalog-search').fill('limunada')
            else:
                assert cats=={'pica'}
                drink_ids=ids
                page.locator('#catalog-search').fill('mocarela')
            expect(page.locator('.menu-item')).to_have_count(0)
            expect(page.locator('.empty-menu')).to_be_visible()
            page.locator('[data-action="reset"]').click()
            expect(page.locator('#catalog-search')).to_have_value('')
            page.locator('#catalog-search').fill('pizza')
            if scope=='food':
                expect(page.locator('#catalog-result-count')).to_have_text('10 PREDLOGA')
                if page.locator('[data-action="more"]').count():page.locator('[data-action="more"]').click()
                expect(page.locator('.menu-item')).to_have_count(10)
                assert set(page.locator('.menu-item').evaluate_all('(els)=>els.map(e=>e.dataset.category)'))=={'pizza'}
            else:
                expect(page.locator('.menu-item')).to_have_count(0)
                expect(page.locator('.empty-menu')).to_be_visible()
            page.locator('#catalog-search').fill('')
            shot(page,screenshot)
        assert not food_ids.intersection(drink_ids)
        ok('separate_food_and_drinks','Food has23 and drinks6 exclusive items. Search cannot leak between scopes; pizza finds10 food items and0 drinks; reset restores scoped view.')

        for name,count in [('pizza',10),('rostilj',6),('salate',4),('deserti',3)]:
            load(name)
            expect(page.locator('#catalog')).to_have_attribute('data-total',str(count))
            if page.locator('[data-action="more"]').count():page.locator('[data-action="more"]').click()
            expect(page.locator('.menu-item')).to_have_count(count)
            assert set(page.locator('.menu-item').evaluate_all('(els)=>els.map(e=>e.dataset.category)'))=={name}
        ok('category_pages','Pizza10, grill6, salads4 and desserts3 have separate, correctly scoped HTML pages.')

        load('jelovnik')
        for cat,count in [('pizza',10),('rostilj',6),('salate',4),('deserti',3)]:
            page.locator('#tab-'+cat).click()
            expect(page.locator('#catalog-result-count')).to_have_text(f'{count} PREDLOGA')
            expect(page.locator('.menu-item')).to_have_count(min(6,count))
        page.locator('#catalog-search').fill('šampinjoni')
        accented=page.locator('.menu-item').count()
        page.locator('#catalog-search').fill('sampinjoni')
        expect(page.locator('.menu-item')).to_have_count(accented)
        assert accented>0
        page.locator('#catalog-search').fill('zzzz-no-such-item')
        expect(page.locator('.empty-menu')).to_be_visible()
        page.locator('[data-action="reset"]').click()
        page.locator('#tab-all').focus(); page.keyboard.press('ArrowRight')
        expect(page.locator('#tab-pizza')).to_be_focused()
        page.keyboard.press('End'); expect(page.locator('#tab-deserti')).to_be_focused()
        page.keyboard.press('Home'); expect(page.locator('#tab-all')).to_be_focused()
        details=page.locator('.item-name[data-id="margherita"]')
        details.click()
        expect(page.locator('#modal-title')).to_have_text('Margherita')
        expect(page.locator('.modal-details')).to_contain_text('mocarela')
        expect(page.locator('.modal-details')).to_contain_text('gluten')
        expect(page.locator('.modal-bottom')).to_contain_text('790')
        expect(page.locator('.modal-close')).to_be_focused()
        page.keyboard.press('Shift+Tab'); expect(page.locator('.modal a[href="rezervacija.html"]')).to_be_focused()
        page.keyboard.press('Tab'); expect(page.locator('.modal-close')).to_be_focused()
        booking_tab(page,page.locator('.modal a[href="rezervacija.html"]'))
        page.keyboard.press('Escape'); expect(page.locator('[role="dialog"]')).to_have_count(0)
        expect(details).to_be_focused()
        ok('catalog_search_details_and_keyboard','Category counts, diacritic search, empty/reset, keyboard tabs, ingredients/allergens/prices and modal focus/booking work.')

        load('digitalni-meni')
        expect(page.locator('#catalog')).to_have_attribute('data-scope','food')
        expect(page.locator('#catalog')).to_have_attribute('data-total','23')
        page.locator('button[data-scope="drinks"]').click()
        expect(page.locator('button[data-scope="drinks"]')).to_have_attribute('aria-pressed','true')
        expect(page.locator('#catalog')).to_have_attribute('data-total','6')
        expect(page.locator('.menu-item')).to_have_count(6)
        assert set(page.locator('.menu-item').evaluate_all('(els)=>els.map(e=>e.dataset.category)'))=={'pica'}
        page.locator('#catalog-search').fill('mocarela');expect(page.locator('.menu-item')).to_have_count(0)
        page.locator('button[data-scope="food"]').click()
        expect(page.locator('#catalog-search')).to_have_value('')
        expect(page.locator('#catalog')).to_have_attribute('data-total','23')
        page.evaluate('window.print=()=>{window.__printItems=Array.from(document.querySelectorAll(".menu-item")).map(e=>e.dataset.product)}')
        page.locator('#print-menu').click()
        assert set(page.evaluate('window.__printItems'))==food_ids
        expect(page.locator('.menu-item')).to_have_count(6)
        page.locator('button[data-scope="drinks"]').click()
        page.locator('#print-menu').click()
        assert set(page.evaluate('window.__printItems'))==drink_ids
        shot(page,'digital-menu.png')
        ok('digital_menu_and_print','Digital menu switches between separatefood/drink scopes; print expands all23 food or6 drinks, then restores pagination.')

        responsive_pages=['index','jelovnik','karta-pica','digitalni-meni','pizza','rostilj','salate','deserti','o-nama','galerija','kontakt','rezervacija']
        for width in [320,390,768,1024,1440]:
            mobile_ctx=browser.new_context(viewport={'width':width,'height':844},is_mobile=width<500,has_touch=width<500)
            phone=mobile_ctx.new_page();observe(phone)
            for name in responsive_pages:
                phone.goto(BASE+name+'.html',wait_until='networkidle')
                assert phone.evaluate('document.documentElement.scrollWidth <= innerWidth'),f'Overflow{width}:{name}'
                no_cart(phone)
            phone.goto(BASE+'index.html',wait_until='networkidle')
            if width<=1100:
                phone.locator('.mobile-nav-toggle').click()
                expect(phone.locator('#mobile-nav')).to_be_visible()
                phone.locator('#mobile-nav a[href="digitalni-meni.html"]').click()
                expect(phone.locator('#catalog')).to_have_attribute('data-total','23')
                expect(phone.locator('#mobile-nav')).to_be_hidden()
                phone.locator('.mobile-nav-toggle').click();phone.keyboard.press('Escape')
                expect(phone.locator('#mobile-nav')).to_be_hidden()
            if width==390:
                phone.goto(BASE+'index.html',wait_until='networkidle')
                shot(phone,'mobile.png');shot(phone,'mobile-viewport.png',False)
                booking_tab(phone,phone.locator('.mobile-reservation-link'))
            mobile_ctx.close()
        ok('responsive_navigation','All12 pages have no horizontal overflow at320/390/768/1024/1440px; shared mobile navigation, Escape, digital route and reservation popup work.')

        reservation_ctx = browser.new_context(viewport={'width':1440,'height':1000}, timezone_id='Europe/Budapest', accept_downloads=True)
        reservation = reservation_ctx.new_page()
        observe(reservation)
        reservation.goto(BASE + 'rezervacija.html', wait_until='networkidle')
        no_cart(reservation)
        reservation.screenshot(path=str(ROOT / 'reservation.png'), full_page=True)
        reservation.screenshot(path=str(ROOT / 'reservation-viewport.png'))
        expect(reservation.locator('#meal-later')).to_be_checked()
        expect(reservation.locator('#advance-meal-fields')).to_be_hidden()
        expect(reservation.locator('#meal-dishes')).to_be_disabled()
        reservation.locator('#guest-count').fill('')
        reservation.locator('#prepare-request').click()
        expect(reservation.locator('#form-errors')).to_be_visible()
        for selector in ['#guest-name','#guest-phone','#reservation-date','#reservation-time','#guest-count']:
            expect(reservation.locator(selector)).to_have_attribute('aria-invalid','true')
        expect(reservation.locator('#reservation-summary')).to_be_hidden()
        for invalid_count in ['0','1.5','51']:
            reservation.locator('#guest-count').fill(invalid_count)
            reservation.locator('#prepare-request').click()
            expect(reservation.locator('#guests-error')).to_be_visible()
            expect(reservation.locator('#reservation-summary')).to_be_hidden()
        ok('reservation_required_guests', 'Required contact/date/time/guests errors shown; empty, zero, fractional and over-limit guest counts cannot prepare a request.')

        name = 'QA <b>& "Test"'
        phone = '+381 64 123 4567'
        email = 'reservation-qa@example.invalid'
        note = '<img src=x onerror="window.__qaXss=1"> & <b>QA</b>'
        dietary = 'Alergija na lešnik — proveriti sa osobljem.'
        dates = reservation.evaluate('''() => {
            const format = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
            const now = new Date(), yesterday = new Date(now), future = new Date(now);
            yesterday.setDate(now.getDate()-1); future.setDate(now.getDate()+2);
            return {today:format(now),yesterday:format(yesterday),future:format(future)};
        }''')
        reservation.locator('#guest-name').fill(name)
        reservation.locator('#guest-phone').fill('not-a-phone')
        reservation.locator('#guest-email').fill('invalid-email')
        reservation.locator('#guest-count').fill('4')
        reservation.locator('#reservation-date').fill(dates['yesterday'])
        reservation.locator('#reservation-time').fill('19:30')
        reservation.locator('#prepare-request').click()
        for selector in ['#phone-error','#email-error','#date-error']:
            expect(reservation.locator(selector)).to_be_visible()
        reservation.locator('#guest-phone').fill(phone)
        reservation.locator('#guest-email').fill(email)
        reservation.locator('#reservation-date').fill(dates['today'])
        reservation.locator('#reservation-time').fill('00:00')
        reservation.locator('#prepare-request').click()
        expect(reservation.locator('#time-error')).to_be_visible()
        expect(reservation.locator('#reservation-summary')).to_be_hidden()
        ok('reservation_contact_and_time_validation', 'Invalid phone/e-mail, past dates and a past time on today’s date are rejected.')

        reservation.locator('#reservation-date').fill(dates['future'])
        reservation.locator('#reservation-time').fill('19:30')
        reservation.locator('#dietary-note').fill(dietary)
        reservation.locator('#visit-note').fill(note)
        reservation.locator('#meal-advance').check()
        expect(reservation.locator('#meal-dishes')).to_be_enabled()
        assert reservation.locator('#meal-dishes').get_attribute('required') is not None
        reservation.locator('#prepare-request').click()
        expect(reservation.locator('#dishes-error')).to_be_visible()
        expect(reservation.locator('#reservation-summary')).to_be_hidden()
        dishes = '2 × Margherita; 1 × roštilj plata za deljenje.'
        reservation.locator('#meal-dishes').fill(dishes)
        reservation.locator('#meal-later').check()
        reservation.locator('#prepare-request').click()
        expect(reservation.locator('#reservation-summary')).to_be_visible()
        expect(reservation.locator('#reservation-form-view')).to_be_hidden()
        expect(reservation.locator('#summary-heading')).to_have_text('Vaš upit je spreman.')
        expect(reservation.locator('.summary-unconfirmed')).to_contain_text('Rezervacija još nije potvrđena.')
        summary_rows = reservation.locator('#reservation-summary-details').evaluate('(dl)=>Object.fromEntries(Array.from(dl.children).map(row=>[row.querySelector("dt").textContent,row.querySelector("dd").textContent]))')
        assert summary_rows['Ime i prezime'] == name
        assert summary_rows['Telefon'] == phone and summary_rows['E-mail'] == email
        assert summary_rows['Broj gostiju'] == '4'
        assert '19:30' in summary_rows['Željeni termin']
        assert summary_rows['Dogovor oko obroka'] == 'Odlučićemo kada dođemo'
        assert 'Željena jela i količine' not in summary_rows
        assert summary_rows['Napomena'] == note
        expect(reservation.locator('#reservation-summary-details img,#reservation-summary-details b,#reservation-summary-details script')).to_have_count(0)
        assert reservation.evaluate('window.__qaXss === undefined')
        reservation.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async(text)=>{window.__qaClipboard=text}}})")
        reservation.locator('#copy-request').click()
        expect(reservation.locator('#request-copy-status')).to_contain_text('Upit je kopiran.')
        later_text = reservation.evaluate('window.__qaClipboard')
        assert 'Jela ćemo izabrati kada dođemo, bez pripreme unapred.' in later_text
        assert dishes not in later_text
        ok('reservation_meal_choices_and_safe_summary', 'Decide-on-arrival is default; advance meal needs dishes; later choice excludes stale dishes. Summary contains exact party/contact/time data and escapes markup safely without claiming confirmation.')

        reservation.locator('#edit-request').click()
        expect(reservation.locator('#reservation-form-view')).to_be_visible()
        for selector, value in [('#guest-name',name),('#guest-phone',phone),('#guest-email',email),('#guest-count','4'),('#reservation-date',dates['future']),('#reservation-time','19:30'),('#dietary-note',dietary),('#visit-note',note),('#meal-dishes',dishes)]:
            expect(reservation.locator(selector)).to_have_value(value)
        reservation.locator('#meal-advance').check()
        reservation.locator('#prepare-request').click()
        expect(reservation.locator('#reservation-summary-details')).to_contain_text(dishes)
        expect(reservation.locator('#reservation-summary-details')).to_contain_text('Želimo da izaberemo jela unapred')
        expect(reservation.locator('#reservation-summary-details')).to_contain_text('Da jela budu spremna za dogovoreno vreme dolaska, ako restoran potvrdi.')
        reservation.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async(text)=>{window.__qaClipboard=text}}})")
        reservation.locator('#copy-request').click()
        expect(reservation.locator('#request-copy-status')).to_contain_text('Upit je kopiran.')
        copied = reservation.evaluate('window.__qaClipboard')
        for expected in [name,phone,email,'Broj gostiju: 4','19:30',dishes,dietary,note,'Ovo je upit, ne potvrđena rezervacija.','Ništa nije automatski poslato.']:
            assert expected in copied, expected
        assert 'navedena jela budu spremna u vreme dolaska' in copied
        assert 'bez pripreme unapred' not in copied
        reservation.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async()=>{throw new Error('Force download fallback')}}})")
        with reservation.expect_download() as download_info:
            reservation.locator('#copy-request').click()
        download = download_info.value
        assert download.suggested_filename == 'Podrumizza-upit-za-rezervaciju.txt'
        download.save_as(ROOT / 'reservation-request.txt')
        downloaded = (ROOT / 'reservation-request.txt').read_text(encoding='utf-8-sig')
        assert downloaded == copied
        storage = reservation.evaluate('JSON.stringify({local:localStorage,session:sessionStorage})')
        for private in [name,phone,email,dishes,dietary,note]:
            assert private not in storage
        # Capture a clean representative request after completing malicious-input checks.
        reservation.locator('#edit-request').click()
        reservation.locator('#guest-name').fill('Ana Jovanović')
        reservation.locator('#guest-email').fill('ana@primer.rs')
        reservation.locator('#visit-note').fill('Rođendan. Mirniji sto ako je moguće.')
        reservation.locator('#prepare-request').click()
        reservation.evaluate('document.activeElement?.blur(); window.scrollTo({top:0,behavior:"instant"})')
        reservation.screenshot(path=str(ROOT / 'reservation-summary.png'),full_page=True)
        reservation.reload(wait_until='networkidle')
        expect(reservation.locator('#guest-name')).to_have_value('')
        expect(reservation.locator('#guest-phone')).to_have_value('')
        expect(reservation.locator('#visit-note')).to_have_value('')
        expect(reservation.locator('#reservation-summary')).to_be_hidden()
        ok('reservation_edit_copy_and_privacy', 'Edit preserves all entered values; advance food appears in summary and identical clipboard/TXT content. Personal fields never enter local/session storage and clear on reload. Nothing is sent automatically.')

        for width in [320,390,768,1024,1300]:
            reservation.set_viewport_size({'width':width,'height':844})
            assert reservation.evaluate('document.documentElement.scrollWidth <= innerWidth'), f'Reservation overflow at {width}'
            no_cart(reservation)
            if width == 390:
                reservation.evaluate('document.activeElement?.blur(); window.scrollTo({top:0,behavior:"instant"})')
                reservation.screenshot(path=str(ROOT / 'reservation-mobile.png'),full_page=True)
        ok('reservation_responsive', 'Reservation form has no horizontal overflow at 320, 390, 768, 1024 and 1300px; no cart or saved-list controls.')
        reservation_ctx.close()
        assert not any(method != 'GET' for method in methods), methods
        assert not errors, errors
        assert not failed, failed
        assert not bad, bad
        ok('runtime_assets', 'No browser page errors, failed requests or HTTP asset errors during complete desktop/mobile runs.')
        completed = True
        browser.close()
except Exception as error:
    checks.append({'name':'execution', 'status':'failed', 'detail':str(error)})
    raise
finally:
    report={'checks':checks,'page_errors':errors,'failed_requests':failed,'http_errors':bad}
    (ROOT / 'report-run.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    if completed:
        (ROOT / 'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))
