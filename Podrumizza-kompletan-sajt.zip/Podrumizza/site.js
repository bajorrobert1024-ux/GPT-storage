/* Shared navigation for all standalone pages. No backend or external requests. */
(() => {
  'use strict';
  const arrow = '<svg class="ui-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg>';
  const links = [
    ['jelovnik','jelovnik.html','Jelovnik'], ['karta-pica','karta-pica.html','Karta pića'],
    ['digitalni-meni','digitalni-meni.html','Digitalni meni'], ['o-nama','o-nama.html','Naša priča'],
    ['galerija','galerija.html','Galerija'], ['kontakt','kontakt.html','Kontakt']
  ];
  const current = document.body.dataset.page || 'pocetna';
  const active = key => key === current || (key === 'jelovnik' && ['pizza','rostilj','salate','deserti'].includes(current));
  const navLinks = links.map(([key,href,label]) => `<a href="${href}"${active(key) ? ` aria-current="${key === current ? 'page' : 'location'}" class="is-current"` : ''}>${label}</a>`).join('');
  const logo = '<a class="wordmark" href="index.html" aria-label="Podrumizza — početna">podrumizza<span>PIZZERIA & RESTORAN</span></a>';
  const reserve = 'href="rezervacija.html" target="_blank" rel="noopener noreferrer"';
  const header = document.querySelector('[data-site-header]');
  if (header) header.innerHTML = `<div class="announcement"><span class="status-dot"></span> DOBRA HRANA JE JOŠ BOLJA U DRUŠTVU <span class="announcement-divider">/</span><a ${reserve}>Rezerviši sto ${arrow}</a></div><header class="site-header multipage-header"><div class="header-inner">${logo}<nav class="desktop-nav" aria-label="Glavna navigacija">${navLinks}</nav><div class="header-actions"><a class="button button-small header-cta" ${reserve}>Rezerviši sto ${arrow}</a><a class="mobile-reservation-link" ${reserve} aria-label="Rezerviši sto — nova kartica"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 11h18m-11 4h4m-2-2v4"/></svg></a><button class="mobile-nav-toggle" aria-label="Otvori navigaciju" aria-expanded="false" aria-controls="mobile-nav"><span></span><span></span></button></div></div><nav id="mobile-nav" class="mobile-nav" aria-label="Mobilna navigacija" hidden><a href="index.html"${current === 'pocetna' ? ' aria-current="page"' : ''}>Početna</a>${navLinks}<a ${reserve}${current === 'rezervacija' ? ' aria-current="page"' : ''}>Rezervacije</a></nav></header>`;
  const footer = document.querySelector('[data-site-footer]');
  if (footer) footer.innerHTML = `<footer class="site-footer section-wrap multipage-footer"><div class="footer-top">${logo}<nav class="footer-links" aria-label="Navigacija u podnožju"><a href="index.html">Početna</a>${navLinks}<a ${reserve}>Rezervacije</a></nav></div><div class="footer-bottom"><span>© ${new Date().getFullYear()} Podrumizza. Dobro mesto. Još bolji zalogaj.</span><a href="https://www.instagram.com/pizzapodrumizza/" target="_blank" rel="noopener noreferrer">@pizzapodrumizza ${arrow}</a></div></footer>`;
  const toggle = document.querySelector('.mobile-nav-toggle');
  const nav = document.getElementById('mobile-nav');
  function toggleNav(open) {
    if (!toggle || !nav) return;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Zatvori navigaciju' : 'Otvori navigaciju');
    nav.hidden = !open;
  }
  toggle?.addEventListener('click', () => toggleNav(toggle.getAttribute('aria-expanded') !== 'true'));
  nav?.addEventListener('click', event => { if (event.target.closest('a')) toggleNav(false); });
  window.addEventListener('resize', () => { if (innerWidth > 1100) toggleNav(false); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') { toggleNav(false); toggle.focus(); } });
})();
