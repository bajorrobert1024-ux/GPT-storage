# Podrumizza — sajt sa posebnim stranicama

Samostalan sajt na srpskom jeziku. Nisu potrebni npm, kompilacija ili spoljašnji fontovi. Početna povezuje sve glavne stranice; svaki deo ima svoj HTML fajl i zajedničku navigaciju.

## Stranice

| Fajl | Sadržaj |
| --- | --- |
| `index.html` | Početna, pregled sajta i veze ka svim glavnim delovima |
| `jelovnik.html` | Isključivo hrana: 23 predloga jela u četiri kategorije |
| `karta-pica.html` | Zasebna karta pića: šest predloga, odvojeno od hrane |
| `digitalni-meni.html` | Brz prikaz za telefon sa odvojenim izborom jelovnika i karte pića |
| `pizza.html` | Deset predloga pica |
| `rostilj.html` | Šest predloga sa roštilja |
| `salate.html` | Četiri salate i priloga |
| `deserti.html` | Tri deserta |
| `o-nama.html` | Priča i ideja Podrumizze |
| `galerija.html` | Vizuelni koncept hrane i dobrih trenutaka |
| `rezervacija.html` | Upit za rezervaciju sa brojem gostiju i izborom obroka |
| `kontakt.html` | Instagram kontakt, rezervacije i odgovori na česta pitanja |

## Pokretanje i objavljivanje

Raspakujte ceo paket i otvorite `index.html`. Sve putanje su relativne, a podaci, fotografije i fontovi su lokalni. Za lokalni razvoj pokrenite iz direktorijuma sajta:

```sh
python3 -m http.server 8081 --bind 127.0.0.1
```

Za statički hosting prenesite sve HTML/CSS/JS fajlove i direktorijum `assets`. Sajt radi i u podfolderu. Digitalni meni ima stalnu stranicu `digitalni-meni.html`; QR kod za stvarne stolove praviti tek za konačnu javnu adresu te stranice. Ovim paketom sajt nije javno objavljen.

## Funkcije

- Jelovnik hrane i karta pića imaju odvojene pretrage i kategorije. Pretraga jela ne vraća pića, niti pretraga pića vraća hranu.
- Digitalni meni zadržava ovo razdvajanje kroz dva velika izbora, Jelovnik i Karta pića.
- Svako jelo i piće ima detalje sa predloženim sastojcima, porcijom, cenom i alergenima.
- Štampanje obuhvata sve rezultate trenutno izabranog prikaza, uključujući i one koji bi na ekranu bili iza dugmeta „Prikaži još”. Štampa se aktivni jelovnik ili karta pića, bez njihovog mešanja.
- Nema korpe, dodavanja na listu, naplate ili automatskog slanja.
- Rezervacija traži ime, telefon, datum, vreme i obavezan broj gostiju. Gost može navesti jela i količine unapred, sa željom da budu spremna za dolazak, ili odlučiti za stolom.
- Obrazac priprema upit za pregled, izmenu, kopiranje ili preuzimanje TXT fajla. Posetilac ga sam prosleđuje restoranu preko Instagrama. Termin, broj mesta i pripremu hrane potvrđuje osoblje.
- Podaci rezervacije se ne čuvaju u localStorage ili bazi i ne šalju automatski. Za stvarni automatski prijem upita potrebno je povezati servis restorana.

## Uređivanje

- `menu.js`: jedinstveni izvor svih 29 predloga, cena, sastojaka, porcija i alergena.
- `catalog.js`: odvojeni prikazi hrane/pića, pretraga, detalji i štampanje.
- `site.js`: zajedničko zaglavlje, navigacija, aktivna stranica i podnožje.
- `styles.css` i `pages.css`: osnovni izgled i rasporedi svih stranica.
- `rezervacija.js` i `rezervacija.css`: obrazac i validacija rezervacije.
- Pojedinačni HTML fajlovi: naslovi, tekstovi, fotografije i veze.

## Podaci i resursi

Meni, cene, porcije, sastojci i alergeni su generisani predlog na zahtev naručioca. Konačne podatke treba potvrditi sa restoranom. Fotografije su generisane za vizuelni koncept; ne predstavljaju stvarnu ponudu ili enterijer. Ne prikazujemo izmišljenu adresu, službeni telefon, radno vreme ili istoriju poslovanja. Dostupan je stvarni javni profil koji je naručilac naveo: `https://www.instagram.com/pizzapodrumizza/`.

Fontovi DM Sans i Fraunces koriste SIL Open Font License; licence su uključene u `assets`. SVG dekoracije i ikonice nalaze se u izvornom kodu. Stranica galerije je sopstveni prikaz ilustracija, a ne automatski Instagram feed.

## Provere

Aktuelni izveštaj, pregledni snimci i funkcionalne provere su u `artifacts`. Sam sajt ne zahteva ovaj direktorijum. Za razvojnu proveru, uz Python Playwright, Chromium i pokrenut lokalni server:

```sh
python3 artifacts/smoke.py
```
