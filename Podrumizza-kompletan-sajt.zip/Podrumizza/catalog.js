/* Scoped food/drinks catalogs. No cart, persistent storage or network submission. */
(() => {
  'use strict';
  const root = document.getElementById('catalog');
  if (!root) return;
  const allItems = window.PODRUMIZZA_MENU || [];
  const categoryInfo = window.PODRUMIZZA_CATEGORIES || [];
  const kind = document.body.dataset.catalog;
  const isDigital = kind === 'digital';
  const fixedCategory = ['pizza','rostilj','salate','deserti'].includes(kind) ? kind : null;
  const foodCategories = ['pizza','rostilj','salate','deserti'];
  const drinkIds = {bezalkoholna:['limunada','mineralna-voda','gazirani-sokovi'], kafa:['espresso','cappuccino'], pivo:['lager-pivo']};
  const $ = selector => document.querySelector(selector);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const norm = value => String(value).toLocaleLowerCase('sr-Latn').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'dj').trim();
  const money = value => new Intl.NumberFormat('sr-RS', {maximumFractionDigits:0}).format(value);
  const arrow = '<svg class="ui-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg>';
  const tabs = $('#catalog-tabs'), grid = $('#catalog-grid'), search = $('#catalog-search'), modal = $('#modal-root');
  let scope = kind === 'drinks' ? 'drinks' : 'food', group = fixedCategory || 'all', query = '', expanded = false, returnFocus = null, printing = false, beforePrintExpanded;

  function itemsInScope() {
    return allItems.filter(item => scope === 'drinks' ? item.category === 'pica' : fixedCategory ? item.category === fixedCategory : foodCategories.includes(item.category));
  }
  function groups() {
    if (fixedCategory) return categoryInfo.filter(cat => cat.id === fixedCategory);
    if (scope === 'drinks') return [{id:'all',label:'Sva pića'},{id:'bezalkoholna',label:'Osveženje'},{id:'kafa',label:'Kafa'},{id:'pivo',label:'Pivo'}];
    return [{id:'all',label:'Sve iz kuhinje'}, ...categoryInfo.filter(cat => foodCategories.includes(cat.id))];
  }
  function matchesGroup(item, id) {
    if (id === 'all') return true;
    return scope === 'drinks' ? (drinkIds[id] || []).includes(item.id) : item.category === id;
  }
  function renderTabs() {
    tabs.innerHTML = groups().map(cat => `<button id="tab-${cat.id}" class="category-tab" role="tab" aria-selected="${group === cat.id && !query}" aria-controls="catalog-grid" tabindex="${group === cat.id ? 0 : -1}" data-action="category" data-id="${cat.id}">${esc(cat.label)}<span>${itemsInScope().filter(item => matchesGroup(item,cat.id)).length}</span></button>`).join('');
  }
  function renderCard(item, index) {
    return `<article class="menu-item" data-product="${esc(item.id)}" data-category="${item.category}"><span class="item-number" aria-hidden="true">${String(index+1).padStart(2,'0')}</span><div class="item-copy"><div class="item-heading"><button class="item-name" data-action="detail" data-id="${esc(item.id)}">${esc(item.name)}</button>${item.tag ? `<span class="item-tag">${esc(item.tag)}</span>` : ''}</div><p class="item-description">${esc(item.description)}</p><div class="item-meta"><span class="item-price">${money(item.price)} <small>RSD</small></span><span class="item-unit">${esc(item.unit)}</span><button class="item-details" data-action="detail" data-id="${esc(item.id)}" aria-label="Sastojci i alergeni: ${esc(item.name)}">Sastojci & alergeni</button></div></div></article>`;
  }
  function render() {
    const scoped = itemsInScope();
    const selected = groups().find(cat => cat.id === group);
    const results = scoped.filter(item => query ? norm([item.name,item.description,item.category,item.category === 'pizza' ? 'pizza pica pice' : '',categoryInfo.find(cat => cat.id === item.category)?.label || '',...item.ingredients].join(' ')).includes(norm(query)) : matchesGroup(item,group));
    const fullLabel = scope === 'drinks' ? 'Karta pića' : fixedCategory ? categoryInfo.find(cat => cat.id === fixedCategory)?.label : 'Jelovnik';
    root.dataset.scope = scope;
    root.dataset.total = scoped.length;
    $('#catalog-count').textContent = `${scoped.length} ${scope === 'drinks' ? 'PREDLOGA PIĆA' : 'PREDLOGA JELA'}`;
    $('#catalog-title').textContent = query ? `Rezultati: „${query}”` : group === 'all' ? fullLabel : selected?.label || fullLabel;
    $('#catalog-intro').textContent = query ? `Pretraga samo u ${scope === 'drinks' ? 'karti pića' : fixedCategory ? 'ovoj kategoriji hrane' : 'jelovniku hrane'}.` : scope === 'drinks' ? 'Osveženje, kafa ili hladno pivo. Odvojeno od jelovnika hrane.' : fixedCategory ? categoryInfo.find(cat => cat.id === fixedCategory)?.intro : 'Pice, roštilj, salate i deserti. Pića imaju svoju kartu.';
    $('#catalog-result-count').textContent = `${results.length} ${results.length === 1 ? 'PREDLOG' : 'PREDLOGA'}`;
    search.placeholder = scope === 'drinks' ? 'Pretraži pića…' : 'Pretraži jela i sastojke…';
    search.setAttribute('aria-label',scope === 'drinks' ? 'Pretraži kartu pića' : 'Pretraži jelovnik hrane');
    grid.setAttribute('aria-labelledby',query ? 'catalog-title' : `tab-${group}`);
    document.querySelectorAll('.scope-switch button[data-scope]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.scope === scope)));
    renderTabs();
    if (!results.length) {
      grid.innerHTML = `<div class="empty-menu"><h3>Nema rezultata za taj ukus.</h3><p>${scope === 'drinks' ? 'Probaj limunadu, kafu ili pivo. Jela potraži u jelovniku.' : 'Probaj naziv jela ili sastojka. Pića potraži u posebnoj karti.'}</p><button class="button button-small" data-action="reset">Prikaži ${scope === 'drinks' ? 'pića' : 'jela'} ${arrow}</button></div>`;
      return;
    }
    const shown = expanded || query || printing ? results : results.slice(0,6);
    grid.innerHTML = shown.map(renderCard).join('') + (shown.length < results.length ? `<div class="show-more-wrap"><button class="show-more" data-action="more">Prikaži još ${results.length-shown.length} predloga <span aria-hidden="true"><svg class="ui-icon" viewBox="0 0 24 24" fill="none"><path d="M12 4v16m-6-6 6 6 6-6"/></svg></span></button></div>` : '');
  }
  function closeModal() {
    modal.innerHTML = '';
    document.body.classList.remove('modal-open');
    if (returnFocus?.isConnected) returnFocus.focus({preventScroll:true});
  }
  function detail(id) {
    // A scoped page cannot expose an item from the other menu through UI actions.
    const item = itemsInScope().find(item => item.id === id);
    if (!item) return;
    returnFocus = document.activeElement;
    const cat = categoryInfo.find(cat => cat.id === item.category);
    modal.innerHTML = `<div class="modal-backdrop" data-backdrop><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button class="modal-close" data-action="close" aria-label="Zatvori prozor">×</button><div class="eyebrow">${esc(cat?.label)} / PREDLOG PONUDE</div><h2 id="modal-title">${esc(item.name)}</h2><p class="modal-description">${esc(item.description)}</p><dl class="modal-details"><div><dt>Predlog ${scope === 'drinks' ? 'količine' : 'porcije'}</dt><dd>${esc(item.unit)}</dd></div><div><dt>Predloženi sastojci</dt><dd>${esc(item.ingredients.join(', '))}.</dd></div><div><dt>Alergeni prema predlogu recepture</dt><dd>${item.allergens.length ? esc(item.allergens.join(', ')) + '.' : 'Nisu navedeni u ovom predlogu; obavezno potvrditi sa restoranom.'}</dd></div></dl><p class="allergen-notice">Recepture i alergeni čekaju potvrdu. Posebne zahteve i sastav proveri direktno sa osobljem pre naručivanja.</p><div class="modal-bottom"><span>${money(item.price)} <small>RSD</small><small class="proposed-price-label">PREDLOG CENE</small></span><a class="button" href="rezervacija.html" target="_blank" rel="noopener noreferrer">Rezerviši sto ${arrow}</a></div></section></div>`;
    document.body.classList.add('modal-open');
    modal.querySelector('button').focus({preventScroll:true});
  }
  function clearSearch() { query=''; search.value=''; expanded=false; }
  search.addEventListener('input',event => { query=event.target.value.trim(); expanded=false; render(); });
  document.addEventListener('click',event => {
    if (event.target.matches('[data-backdrop]')) { closeModal(); return; }
    const button = event.target.closest('button');
    if (!button) return;
    if (isDigital && button.dataset.scope) {
      scope=button.dataset.scope === 'drinks' ? 'drinks' : 'food'; group='all'; clearSearch(); render(); return;
    }
    const {action,id} = button.dataset;
    if (action === 'category') { group=id; clearSearch(); render(); $(`#tab-${group}`).focus({preventScroll:true}); }
    if (action === 'more') { expanded=true; render(); grid.querySelectorAll('.menu-item')[6]?.querySelector('.item-name')?.focus({preventScroll:true}); }
    if (action === 'reset') { group=fixedCategory || 'all'; clearSearch(); render(); search.focus(); }
    if (action === 'detail') detail(id);
    if (action === 'close') closeModal();
  });
  tabs.addEventListener('keydown',event => {
    if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
    event.preventDefault();
    const list=groups(), index=list.findIndex(cat => cat.id===group);
    const next=event.key==='Home' ? 0 : event.key==='End' ? list.length-1 : (index+(event.key==='ArrowRight' ? 1 : -1)+list.length)%list.length;
    group=list[next].id; clearSearch(); render(); $(`#tab-${group}`).focus();
  });
  document.addEventListener('keydown',event => {
    const dialog=modal.querySelector('[role=dialog]');
    if (!dialog) return;
    if (event.key==='Escape') { closeModal(); return; }
    if (event.key!=='Tab') return;
    const focusable=[...dialog.querySelectorAll('button,a[href]')].filter(el => el.getClientRects().length), first=focusable[0], last=focusable.at(-1);
    if (event.shiftKey && (document.activeElement===first || !dialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && (document.activeElement===last || !dialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
  });
  function preparePrint() { if (!printing) beforePrintExpanded=expanded; printing=true; render(); }
  function finishPrint() { if (!printing) return; printing=false; expanded=beforePrintExpanded; render(); }
  window.addEventListener('beforeprint',preparePrint);
  window.addEventListener('afterprint',finishPrint);
  $('#print-menu')?.addEventListener('click',() => { preparePrint(); window.print(); finishPrint(); });
  render();
})();
