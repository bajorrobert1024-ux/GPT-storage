/*
 * PODRUMIZZA — PREDLOG MENIJA ZA DIZAJN.
 * Stavke, sastojci, alergeni, cene u RSD i veličine služe kao ilustrativan
 * sadržaj prototipa. Cene su generisani predlozi, nisu potvrđene cene restorana.
 * Ovo nije zvanična ponuda restorana. Dostupnost, recepture, alergene,
 * veličine porcija i cene treba potvrditi sa restoranom pre objavljivanja.
 */
window.PODRUMIZZA_CATEGORIES = [
  {
    id: 'pizza',
    label: 'Pice',
    eyebrow: 'DOBRA KORA. JOŠ BOLJE DRUŠTVO.',
    intro: 'Od jednostavne Margherite do bogatih kombinacija za one koji vole da probaju nešto novo.'
  },
  {
    id: 'rostilj',
    label: 'Roštilj',
    eyebrow: 'ZA LJUBITELJE DOBROG ZALOGAJA.',
    intro: 'Sočno meso, topla lepinja i omiljeni prilozi. Predlog klasika za veliki i mali apetit.'
  },
  {
    id: 'salate',
    label: 'Salate i prilozi',
    eyebrow: 'MALO SVEŽINE SA STRANE.',
    intro: 'Hrskavo, sveže i puno boja. Kao lagan obrok ili društvo tvom glavnom jelu.'
  },
  {
    id: 'deserti',
    label: 'Nešto slatko',
    eyebrow: 'UVEK IMA MESTA ZA JOŠ.',
    intro: 'Kafa, čokolada, lešnik. Tri slatka razloga da ostaneš još malo.'
  },
  {
    id: 'pica',
    label: 'Pića',
    eyebrow: 'PODIGNI ČAŠU ZA DOBRE TRENUTKE.',
    intro: 'Osveženje uz ručak, kafa posle njega i predlog piva za večernje druženje.'
  }
];

window.PODRUMIZZA_MENU = [
  {
    id: 'margherita', name: 'Margherita', category: 'pizza',
    description: 'Paradajz, kremasta mocarela i svež bosiljak. Klasik koji osvaja jednostavnošću.',
    ingredients: ['paradajz sos', 'mocarela', 'svež bosiljak', 'maslinovo ulje', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], tag: 'Vegetarijansko', price: 790, unit: '32 cm'
  },
  {
    id: 'capricciosa', name: 'Capricciosa', category: 'pizza',
    description: 'Poznata kombinacija šunke i pečuraka, sa mocarelom i maslinama.',
    ingredients: ['paradajz sos', 'mocarela', 'šunka', 'šampinjoni', 'masline', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], price: 950, unit: '32 cm'
  },
  {
    id: 'diavola', name: 'Diavola', category: 'pizza',
    description: 'Pikantna salama, čili i mocarela za one koji vole da zalogaj ima karakter.',
    ingredients: ['paradajz sos', 'mocarela', 'pikantna salama', 'čili', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], tag: 'Ljuto', price: 990, unit: '32 cm'
  },
  {
    id: 'quattro-formaggi', name: 'Quattro formaggi', category: 'pizza',
    description: 'Četiri sira, četiri teksture i jedna bogata, kremasta kombinacija.',
    ingredients: ['mocarela', 'gorgonzola', 'parmezan', 'dimljeni sir', 'pavlaka', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], price: 1090, unit: '32 cm'
  },
  {
    id: 'prosciutto-rucola', name: 'Prosciutto e rucola', category: 'pizza',
    description: 'Pršuta, sveža rukola i listići parmezana na podlozi od paradajza i mocarele.',
    ingredients: ['paradajz sos', 'mocarela', 'pršuta', 'rukola', 'parmezan', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], tag: 'Naš predlog', price: 1190, unit: '32 cm'
  },
  {
    id: 'mortadella-pistacchio', name: 'Mortadella e pistacchio', category: 'pizza',
    description: 'Nežna mortadela, mocarela i hrskavi pistaći u kombinaciji punoj teksture.',
    ingredients: ['mocarela', 'mortadela sa pistaćima', 'pistaći', 'pavlaka', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko', 'pistaći'], price: 1290, unit: '32 cm'
  },
  {
    id: 'funghi', name: 'Funghi', category: 'pizza',
    description: 'Pečurke u prvom planu, uz mocarelu, paradajz i miris origana.',
    ingredients: ['paradajz sos', 'mocarela', 'šampinjoni', 'origano', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], tag: 'Vegetarijansko', price: 890, unit: '32 cm'
  },
  {
    id: 'vegetariana', name: 'Vegetariana', category: 'pizza',
    description: 'Tikvice, paprika i pečurke za šarenu, sočnu kombinaciju povrća i sira.',
    ingredients: ['paradajz sos', 'mocarela', 'tikvice', 'paprika', 'šampinjoni', 'masline', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], tag: 'Vegetarijansko', price: 950, unit: '32 cm'
  },
  {
    id: 'bbq-pollo', name: 'BBQ pollo', category: 'pizza',
    description: 'Piletina, dimljeni sir i crveni luk sa slatkasto-pikantnim BBQ sosom.',
    ingredients: ['piletina', 'mocarela', 'dimljeni sir', 'crveni luk', 'BBQ sos sa senfom', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko', 'senf'], price: 1090, unit: '32 cm'
  },
  {
    id: 'podrumizza-special', name: 'Podrumizza special', category: 'pizza',
    description: 'Predlog kuće: pršuta, pečurke i dimljeni sir, zaokruženi svežom rukolom.',
    ingredients: ['paradajz sos', 'mocarela', 'pršuta', 'šampinjoni', 'dimljeni sir', 'rukola', 'testo od pšeničnog brašna'],
    allergens: ['gluten', 'mleko'], tag: 'Naš predlog', price: 1250, unit: '32 cm'
  },
  {
    id: 'cevapi', name: 'Ćevapi u lepinji', category: 'rostilj',
    description: 'Ćevapi od junećeg mesa, topla lepinja, seckani luk i kajmak sa strane.',
    ingredients: ['juneće meso', 'začini', 'pšenična lepinja', 'crni luk', 'kajmak'],
    allergens: ['gluten', 'mleko'], tag: 'Naš predlog', price: 690, unit: 'porcija'
  },
  {
    id: 'pljeskavica', name: 'Klasična pljeskavica', category: 'rostilj',
    description: 'Juneća pljeskavica sa lukom, ajvarom i svežim povrćem u toploj lepinji.',
    ingredients: ['juneće meso', 'začini', 'pšenična lepinja', 'crni luk', 'paradajz', 'zelena salata', 'ajvar'],
    allergens: ['gluten'], price: 590, unit: 'porcija'
  },
  {
    id: 'gurmanska-pljeskavica', name: 'Gurmanska pljeskavica', category: 'rostilj',
    description: 'Bogata kombinacija junećeg mesa, sira, slanine i ljute paprike.',
    ingredients: ['juneće meso', 'kačkavalj', 'slanina', 'ljuta paprika', 'pšenična lepinja', 'crni luk'],
    allergens: ['gluten', 'mleko'], tag: 'Ljuto', price: 750, unit: 'porcija'
  },
  {
    id: 'punjena-vesalica', name: 'Punjena bela vešalica', category: 'rostilj',
    description: 'Svinjski kare punjen sirom i slaninom, uz krompir i svežu salatu.',
    ingredients: ['svinjski kare', 'kačkavalj', 'slanina', 'krompir', 'paradajz', 'krastavac'],
    allergens: ['mleko'], price: 1090, unit: 'porcija'
  },
  {
    id: 'pileci-file', name: 'Pileći file', category: 'rostilj',
    description: 'File piletine sa grilovanim povrćem i kremastim sosom od jogurta.',
    ingredients: ['pileći file', 'tikvice', 'paprika', 'crveni luk', 'jogurt', 'beli luk'],
    allergens: ['mleko'], price: 790, unit: 'porcija'
  },
  {
    id: 'rostilj-plata', name: 'Roštilj plata za deljenje', category: 'rostilj',
    description: 'Predlog za društvo: ćevapi, pljeskavica i piletina uz lepinju, luk i kajmak.',
    ingredients: ['juneće meso', 'pileći file', 'začini', 'pšenična lepinja', 'crni luk', 'kajmak', 'ajvar'],
    allergens: ['gluten', 'mleko'], price: 2390, unit: 'za 2 osobe'
  },
  {
    id: 'sopska-salata', name: 'Šopska salata', category: 'salate',
    description: 'Paradajz, krastavac, paprika i luk pod slojem belog sira.',
    ingredients: ['paradajz', 'krastavac', 'paprika', 'crni luk', 'beli sir', 'ulje'],
    allergens: ['mleko'], tag: 'Vegetarijansko', price: 390, unit: 'porcija'
  },
  {
    id: 'cezar-salata', name: 'Cezar salata', category: 'salate',
    description: 'Hrskava salata, piletina, krutoni i parmezan sa bogatim Cezar prelivom.',
    ingredients: ['zelena salata', 'pileći file', 'pšenični krutoni', 'parmezan', 'jaja', 'senf', 'inćuni', 'maslinovo ulje'],
    allergens: ['gluten', 'mleko', 'jaja', 'senf', 'riba'], price: 690, unit: 'porcija'
  },
  {
    id: 'rukola-parmezan', name: 'Rukola i parmezan', category: 'salate',
    description: 'Sveža rukola, čeri paradajz i listići parmezana sa limunovim prelivom.',
    ingredients: ['rukola', 'čeri paradajz', 'parmezan', 'limun', 'maslinovo ulje'],
    allergens: ['mleko'], price: 490, unit: 'porcija'
  },
  {
    id: 'pomfrit', name: 'Hrskavi pomfrit', category: 'salate',
    description: 'Zlatni krompirići sa morskom solju. Jednostavan prilog koji svi vole.',
    ingredients: ['krompir', 'suncokretovo ulje', 'morska so'],
    allergens: [], tag: 'Vegetarijansko', price: 320, unit: 'porcija'
  },
  {
    id: 'tiramisu', name: 'Tiramisu', category: 'deserti',
    description: 'Slojevi piškota, kafe i maskarpone krema, sa završnim dodirom kakaa.',
    ingredients: ['pšenične piškote', 'maskarpone', 'jaja', 'kafa', 'šećer', 'kakao'],
    allergens: ['gluten', 'mleko', 'jaja'], tag: 'Naš predlog', price: 450, unit: 'porcija'
  },
  {
    id: 'cokoladni-sufle', name: 'Čokoladni sufle', category: 'deserti',
    description: 'Topao čokoladni kolač sa mekom sredinom i kuglom sladoleda od vanile.',
    ingredients: ['crna čokolada sa sojinim lecitinom', 'pšenično brašno', 'jaja', 'puter', 'šećer', 'mlečni sladoled od vanile'],
    allergens: ['gluten', 'mleko', 'jaja', 'soja'], price: 490, unit: 'porcija'
  },
  {
    id: 'palacinke', name: 'Palačinke čokolada & lešnik', category: 'deserti',
    description: 'Tanke palačinke sa kremom od čokolade i lešnika i komadićima pečenog lešnika.',
    ingredients: ['pšenično brašno', 'mleko', 'jaja', 'čokoladni krem sa lešnikom i sojinim lecitinom', 'lešnici'],
    allergens: ['gluten', 'mleko', 'jaja', 'lešnici', 'soja'], price: 390, unit: 'porcija'
  },
  {
    id: 'limunada', name: 'Limunada', category: 'pica',
    description: 'Limun, voda i led, sa grančicom nane za dodatnu svežinu.',
    ingredients: ['limun', 'voda', 'led', 'nana', 'šećer po želji'],
    allergens: [], price: 290, unit: '0,3 l'
  },
  {
    id: 'espresso', name: 'Espresso', category: 'pica',
    description: 'Kratka pauza, puna aroma. Kafa za početak ili kraj dobrog obroka.',
    ingredients: ['kafa', 'voda'],
    allergens: [], price: 170, unit: 'šoljica'
  },
  {
    id: 'cappuccino', name: 'Cappuccino', category: 'pica',
    description: 'Espresso, toplo mleko i fina mlečna pena u jednoj šolji.',
    ingredients: ['kafa', 'mleko', 'voda'],
    allergens: ['mleko'], price: 230, unit: 'šoljica'
  },
  {
    id: 'mineralna-voda', name: 'Mineralna voda', category: 'pica',
    description: 'Predlog negazirane ili gazirane vode uz svaki obrok.',
    ingredients: ['mineralna voda'],
    allergens: [], price: 190, unit: '0,25 l'
  },
  {
    id: 'gazirani-sokovi', name: 'Gazirani sokovi', category: 'pica',
    description: 'Osveženje po izboru. Dostupne brendove i ukuse potvrđujemo uz konačni meni.',
    ingredients: ['sastav prema deklaraciji odabranog napitka'],
    allergens: [], price: 250, unit: '0,33 l'
  },
  {
    id: 'lager-pivo', name: 'Lager pivo', category: 'pica',
    description: 'Predlog lager piva uz picu i roštilj. Alkoholno piće namenjeno punoletnima.',
    ingredients: ['voda', 'ječmeni slad', 'hmelj', 'kvasac'],
    allergens: ['gluten'], price: 320, unit: '0,5 l'
  }
];
