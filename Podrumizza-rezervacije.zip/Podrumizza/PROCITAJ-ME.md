# Podrumizza — predlog sajta

Samostalan, prilagodljiv sajt na srpskom jeziku. Radi bez npm-a, kompilacije, spoljnih fontova ili servisa. Uključeni su originalni vizuelni pravac, generisane ilustrativne fotografije i predlog menija sa 29 stavki i cenama u dinarima.

## Pokretanje

Raspakujte ceo paket i otvorite `index.html` u savremenom pregledaču. Za lokalni razvoj iz ovog direktorijuma pokrenite:

```sh
python3 -m http.server 8081 --bind 127.0.0.1
```

Za objavljivanje prenesite sadržaj direktorijuma na statički hosting. Sačuvajte relativne putanje i direktorijum `assets`. Sajt nije objavljen ovim paketom.

## Šta radi

- Pet kategorija: pice, roštilj, salate i prilozi, deserti i pića.
- Pretraga celog menija bez obzira na dijakritike, sa rezultatima i praznim stanjem.
- Detalji jela, predloženi sastojci, porcije i alergeni.
- Posebna stranica `rezervacija.html`, koja se otvara u novoj kartici iz dugmadi za rezervaciju.
- Obavezni broj gostiju, datum, vreme i kontakt za pripremu upita za rezervaciju stola.
- Dva izbora: navesti jela unapred sa količinama ili odlučiti kada gosti dođu.
- Pregled i izmena upita, kopiranje ili preuzimanje tekstualnog fajla za prosleđivanje restoranu. Korpa i lista za dodavanje jela su uklonjene.
- Mobilna navigacija, tastaturno upravljanje kategorijama i prozorima, ograničeno kretanje fokusa u prozoru, zatvaranje tasterom Escape.
- Linkovi ka profilu `https://www.instagram.com/pizzapodrumizza/`.

## Uređivanje

- `menu.js`: nazivi jela, opisi, sastojci, alergeni, porcije, kategorije i cene.
- `index.html`: sadržaj početne strane, meni i linkovi za rezervaciju.
- `styles.css`: dizajn, boje, tipografija i prilagođavanje ekranima.
- `app.js`: pretraga, kategorije i detalji jela.
- `rezervacija.html`, `rezervacija.css`, `rezervacija.js`: obrazac, izgled, validacija i priprema upita za rezervaciju.
- `assets/hero-pizza.webp` i `assets/grill.webp`: fotografije generisane za ovaj koncept.

## Podaci za potvrdu pre javnog objavljivanja

Meni, cene, veličine porcija, sastojci i alergeni su generisani predlog na zahtev naručioca, a ne potvrđena ponuda restorana. Fotografije ne predstavljaju stvarna jela ili enterijer restorana. Naziv je oblikovan prema navedenom Instagram korisničkom imenu; znak i tipografski logo su originalan predlog za ovaj sajt.

Adresa, datum otvaranja, službeni telefon i radno vreme nisu izmišljeni. Nakon potvrde ubaciti konkretne podatke, mapu i kontakt. Pozivi za rezervaciju vode na zasebnu HTML stranicu u novoj kartici. Pregled Instagrama i referentnog sajta Tramontana bio je blokiran mrežnim pravilima razvojnog okruženja, pa njihov sadržaj nije preuzet ili kopiran.

Obrazac priprema upit za rezervaciju, ali ga ne šalje automatski i ne potvrđuje raspoloživost stolova. Posetilac kopira ili preuzima upit i može da ga pošalje preko navedenog Instagram profila. Termin, broj gostiju i eventualnu pripremu hrane unapred potvrđuje restoran. Upit sa jelima nije garancija da će hrana biti spremna pri dolasku dok osoblje to ne potvrdi.

Za automatski prijem rezervacija treba povezati stvarni servis ili backend i potvrđen kanal restorana. Sajt ne čuva ime, telefon, e-mail, plan obroka ili napomene u localStorage, kolačićima ili bazi. Podaci postoje samo u trenutnom prikazu; korisnik sam bira kopiranje/preuzimanje i prosleđivanje. Nema analitike ili naplate.

## Resursi i provere

Fontovi DM Sans i Fraunces koriste SIL Open Font License; licence su u `assets` direktorijumu. Fotografije su generisane za ovaj projekat. Ikonice i dekoracije su originalni SVG elementi u kodu.

Razvojne provere i snimci ekrana nalaze se u `artifacts`. Funkcionalna provera zahteva Python Playwright i Chromium (samo za proveru, ne za rad sajta):

```sh
python3 artifacts/smoke.py
```

Provera se izvršava uz lokalni server na portu 8081. Produkcijski sajt čine `index.html`, `styles.css`, `app.js`, `menu.js`, `rezervacija.html`, `rezervacija.css`, `rezervacija.js` i `assets` direktorijum.
